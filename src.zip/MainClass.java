import java.awt.event.*;
import java.awt.*;
import javax.swing.*;

public class MainClass extends JFrame {
	Dummy2 dum = new Dummy2();
	
	CardLayout card = new CardLayout();
	public MainClass() {
		
		setLayout(card);
		add("DUM",dum);
		
		
		
		
		setSize(1024, 1024);
		setVisible(true);// ������ ������ 
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		new MainClass();
		
	}

}
