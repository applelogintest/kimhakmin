import java.awt.*;
import java.util.ArrayList;

import javax.swing.*;

public class CardVO {
	ImageIcon tail_back;
	ImageIcon tail_back_fix;
	ImageIcon tail;
	ImageIcon tail_fix;
	Image img, fix_img;

}
