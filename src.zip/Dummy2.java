import java.awt.*;
import java.util.ArrayList;

import javax.swing.*;

public class Dummy2 extends JPanel {

	boolean bCheck = false;
	CardVO[] card = new CardVO[24];
	JButton[] bt = new JButton[24];
	int[] su = new int[24];
	
	public Dummy2() {
		JFrame f = new JFrame();
		setLayout(null);
		boolean bCheck = false;
		
		
		for(int i=0; i<24; i++)
		{
			card[i] = new CardVO();
		}
		
		for(int i=0; i<24; i++) //���� ȭ��Ʈ ī�� �޸� ����
		{
			if (i < 12)
				card[i].tail_back = new ImageIcon(("C:\\Davinci_code\\Project\\Img\\tile\\b_tile_back.png"));
			else
				card[i].tail_back = new ImageIcon(("C:\\Davinci_code\\Project\\Img\\tile\\w_tile_back.png"));

			card[i].img = card[i].tail_back.getImage();
			card[i].fix_img = card[i].img.getScaledInstance(220, 190, Image.SCALE_SMOOTH);
			card[i].tail_back_fix = new ImageIcon(card[i].fix_img);

		}
		
		for (int i = 0; i < 24; i++) { //���� ȭ��Ʈ ī�� �ո� ����

			if (i < 12)
				card[i].tail = new ImageIcon(("C:\\Davinci_code\\Project\\Img\\tile\\b_tile_" + i + ".png"));
			else
				card[i].tail = new ImageIcon(("C:\\Davinci_code\\Project\\Img\\tile\\w_tile_" + (i - 12) + ".png"));

			card[i].img = card[i].tail.getImage();
			card[i].fix_img = card[i].img.getScaledInstance(220, 190, Image.SCALE_SMOOTH);
			card[i].tail_fix = new ImageIcon(card[i].fix_img);

		}
		
		
		
		for(int i=0; i<24; i++) //���� ���� �̿��Ͽ� ��ư�� �������� �迭
		{
			bCheck = true;
			while(bCheck)
			{
				bCheck = false;
				int rand = (int)(Math.random()*24);
					for(int j=0; j<i; j++)
					{
						if( su[j] == rand) {
							bCheck = true;
							break;
						}
					}
				
				su[i] = rand;
			}
			
			bt[i] = new JButton(card[su[i]].tail_fix);
		}
		int x=50,x2=50;
		JPanel p = new JPanel();
		p.setLayout(new GridLayout(2,1,10,10));
		
		for(int i=0; i<bt.length; i++)
		{
			p.add(bt[i]);
		}
		
		//p.add(bt,BorderLayout.CENTER);
		p.setBounds(100,350,800,200);
		add(p);
		 
		
	}

}

